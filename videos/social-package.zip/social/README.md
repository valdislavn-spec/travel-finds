# Social posting package (IG / FB / TikTok)

Videos are already in the cloud (GitHub Pages) — direct HTTPS MP4 URLs:
see `links.md` or the cloud `social-captions.json`.

Files:
- `links.md` — public video/cover URLs.
- `instagram-captions.txt`, `facebook-captions.txt`, `tiktok-captions.txt` — ready captions with affiliate disclosure.
- `social-captions.json` — same data, machine-readable.

Manual posting: download video or open the MP4 URL, upload in each app, paste the matching caption.
API posting: use `tools/publish_social.py` (needs Meta/TikTok credentials; see docs/social-publishing.md).
