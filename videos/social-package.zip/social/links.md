# UGC videos — cloud links

Base: https://valdislavn-spec.github.io/travel-finds

## 5 affordable city breaks in Europe (EN, 41.47 c)

- video: https://valdislavn-spec.github.io/travel-finds/videos/city-breaks-en.mp4
- cover: https://valdislavn-spec.github.io/travel-finds/videos/city-breaks-en-cover.jpg
- CTA: https://valdislavn-spec.github.io/travel-finds/blog/cheap-city-breaks-europe-2026.html

## The flight search order that saves money (EN, 34.15 c)

- video: https://valdislavn-spec.github.io/travel-finds/videos/flights-en.mp4
- cover: https://valdislavn-spec.github.io/travel-finds/videos/flights-en-cover.jpg
- CTA: https://valdislavn-spec.github.io/travel-finds/blog/how-to-find-cheap-flights-2026.html

## 5 escapadas por Europa sin gastar de más (ES, 40.85 c)

- video: https://valdislavn-spec.github.io/travel-finds/videos/escapadas-es.mp4
- cover: https://valdislavn-spec.github.io/travel-finds/videos/escapadas-es-cover.jpg
- CTA: https://valdislavn-spec.github.io/travel-finds/es/blog/escapadas-economicas-europa-2026.html
